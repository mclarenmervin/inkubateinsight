<?php
/**
 * Plugin Name: Lifter LMS Inkubate Insights
 * Plugin URI: 
 * Description: This plugin allows admin to Inkubate Insights
 * Version: 1.0
 * Author: Magnigenie
 * Author URI: https://magnigenie.com
 */

 defined( 'ABSPATH' ) || exit;

 if ( !defined( 'LLMS_Inkubate_Insights_FILE' ) )
 {
     define( 'LLMS_Inkubate_Insights_FILE', __FILE__ );
 }
 
 if ( !defined( 'LLMS_Inkubate_Insights_DIR' ) )
 {
     define( 'LLMS_Inkubate_Insights_DIR', dirname( __FILE__ ) );
 }
 
 if ( !class_exists( 'LLMS_Inkubate_Insights' ) ) {
     include_once dirname( __FILE__ ) . '/includes/class-inkubate-insights.php';
 }

 // Define the custom table name
global $wpdb;
$table_name = $wpdb->prefix . 'inkubate_insight';

// Function to create the custom table
function create_custom_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'inkubate_insight';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        student_id mediumint(9) NOT NULL,
        category_id mediumint(9) NOT NULL,
        question_tag_id mediumint(9) NOT NULL,
        score mediumint(9) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Register the activation hook
register_activation_hook(__FILE__, 'create_custom_table');