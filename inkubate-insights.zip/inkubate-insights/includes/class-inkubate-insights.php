<?php
class LLMS_Inkubate_Insights {
    public function __construct() {
        add_action( 'init', array( $this, 'add_taxonomy_question_tag' ) );
        add_action( 'course_cat_add_form_fields', array( $this, 'add_question_tag_add_category_tax' ), 10, 1 );
        add_action( 'course_cat_edit_form_fields', array( $this, 'add_question_tag_edit_category_tax' ), 10, 2 );
        add_action( 'created_course_cat', array( $this, 'save_question_tag_term_field' ) );
        add_action( 'edited_course_cat', array( $this, 'save_question_tag_term_field' ) );

        // Hook to add the dropdown in the question builder
        add_action( 'llms_builder_question_after_features', array($this, 'add_question_tag_dropdown_to_builder'));
        // add_action( 'admin_menu', array( $this, 'wpdocs_register_my_custom_menu_page' ) );

        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_chartjs' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_inkubatejs' ) );

        add_action( 'wp_ajax_update_question_tag_meta', array( $this, 'update_question_tag_meta' ) );
        add_action( 'wp_ajax_get_question_tag_meta', array( $this, 'get_question_tag_meta' ) );
        add_action( 'lifterlms_quiz_completed', array( $this, 'update_insight_table' ), 10, 3 );

        add_shortcode( 'inkubate_insight_chart', array( $this, 'inkubate_insight_chart_shortcode' ) );
    }

    public function enqueue_chartjs() {
        // Get all term names for the 'course_cat' taxonomy under the 'course' post type
        $taxonomy = 'course_cat';
        $post_type = 'course';

        $terms = get_terms(array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false, // Set to true if you want to exclude terms with no posts
        ));

        // Initialize an empty array to store term names
        $term_names = array();

        // Check if terms were found
        if (!empty($terms)) {
            // Loop through each term and add the term name to the array
            foreach ($terms as $term) {
                $term_names[] = $term->name;
            }
        } else {
            echo 'No terms found.';
        }

        // Enqueue Chart.js
        wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.7.0', true );
        wp_enqueue_script( 'inkubate-insight-admin-script', plugins_url('js/admin-script.js', __FILE__), array('jquery'), '1.0', true );
        wp_localize_script( 
            'inkubate-insight-admin-script', 
            'inkubateInsight',
            array( 
                'ajaxurl' => admin_url('admin-ajax.php'),
                'categoryNames' => $term_names,
                ) 
        );
    }

    public function enqueue_inkubatejs() {
        // Get all term names for the 'course_cat' taxonomy under the 'course' post type
        $taxonomy = 'llms_question_tag';
        $post_type = 'course';

        $terms = get_terms(array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false, // Set to true if you want to exclude terms with no posts
        ));

        // Initialize an empty array to store term names
        $term_names = array();
        $term_id = array();

        // Check if terms were found
        if (!empty($terms)) {
            // Loop through each term and add the term name to the array
            foreach ($terms as $term) {
                $term_names[] = $term->name;
                $term_ids[] = $term->term_id;
            }
        }

        $taxonomy2 = 'course_cat';
        $terms2 = get_terms(array(
            'taxonomy' => $taxonomy2,
            'hide_empty' => false, // Set to true if you want to exclude terms with no posts
        ));

        // Initialize an empty array to store term slugs
        $term_slugs = array();

        // Check if terms were found
        if (!empty($terms2)) {
            // Loop through each term and add the term slug to the array
            foreach ($terms2 as $term) {
                $term_slugs[] = $term->slug;
            }
        }
        wp_enqueue_script( 'chartjs-public', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.7.0', true );
        wp_enqueue_script( 'inkubate-insight-public-script', plugins_url('js/public-script.js', __FILE__), array('jquery'), '1.0', true );
        wp_localize_script( 
            'inkubate-insight-public-script', 
            'inkubateInsightP',
            array( 
                'ajaxurl' => admin_url('admin-ajax.php'),
                'categoryNames' => $term_names,
                'categoryIds' => $term_ids,
                'categorySlug' => $term_slugs,
                ) 
        );
    }

    public function add_taxonomy_question_tag() {
        $labels = array(
            'name'              => _x( 'Question Tags', 'taxonomy general name', 'textdomain' ),
            'singular_name'     => _x( 'Question Tag', 'taxonomy singular name', 'textdomain' ),
            'menu_name'         => __( 'Question Tags', 'textdomain' ),
        );
    
        $args = array(
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => false,
            'rewrite'           => false,
            'show_in_menu'      => true,

        );
        
        register_taxonomy( 'llms_question_tag', array( 'course' ), $args );
    }

    public function add_question_tag_add_category_tax() {
        $llms_question_tags = get_terms('llms_question_tag', array('hide_empty' => false));
        if( !empty( $llms_question_tags ) ){
            echo '<tr class="form-field" style="margin-buttom:10px;">';
            echo '<th scope="row"><label for="llms_question_tag">Question Tag</label></th>';
            echo '<td>';
            echo '<select name="llms_question_tag[]" id="llms_question_tag" multiple="multiple">';
            
            // Generate options for the dropdown
            foreach ($llms_question_tags as $tag) {
                echo '<option value="' . $tag->term_id . '">' . $tag->name . '</option>';
            }
    
            echo '</select>';
            echo '<p class="description">Select an Question Tag for this term.</p>';
            echo '</td>';
            echo '</tr>';
        }
    }

    public function add_question_tag_edit_category_tax($term, $taxonomy) {
        $llms_question_tags = get_terms('llms_question_tag', array('hide_empty' => false));
        
        if (!empty($llms_question_tags)) {
            echo '<tr class="form-field">';
            echo '<th scope="row"><label for="llms_question_tagm">Question Tag</label></th>';
            echo '<td>';
            echo '<select name="llms_question_tagm[]" id="llms_question_tagm" multiple="multiple">';
        
            // Get the stored values from term meta
            $selected_values = get_term_meta($term->term_id, 'llms_question_tagm', true);
            $selected_values = is_array($selected_values) ? $selected_values : array();
    
            // Generate options for the dropdown
            foreach ($llms_question_tags as $tag) {
                $selected = in_array($tag->term_id, $selected_values) ? 'selected="selected"' : '';
                echo '<option value="' . $tag->term_id . '" ' . $selected . '>' . $tag->name . '</option>';
            }
        
            echo '</select>';
            echo '<p class="description">Select Question Tags for this term.</p>';
            echo '</td>';
            echo '</tr>';
        }
    }    
    
    public function save_question_tag_term_field( $term_id ) {
        // Check if the field is present in the $_POST array
        if (isset($_POST['llms_question_tagm'])) {
            // Sanitize and save the array of selected values
            $selected_values = array_map('sanitize_text_field', $_POST['llms_question_tagm']);
            update_term_meta($term_id, 'llms_question_tagm', $selected_values);
        } else {
            // If the field is not present, delete the term meta
            delete_term_meta($term_id, 'llms_question_tagm');
        }       
    }

    public function add_question_tag_dropdown_to_builder() {
        // $llms_question_tags = get_terms('llms_question_tag', array('hide_empty' => false));
        $term_lists = wp_get_post_terms( get_the_ID(), 'course_cat', array( 'fields' => 'ids' ) );
        $question_tags = array();
        foreach ($term_lists as $term_id) {
            $question_tags[] = get_term_meta( $term_id, 'llms_question_tagm', true );
        }
        $allValues = array();

        foreach ($question_tags as $innerArray) {
            // Check if the inner array is not empty before iterating through its values
            if (!empty($innerArray)) {
                foreach ($innerArray as $value) {
                    $allValues[] = $value;
                }
            }
        }
        
        ?>
        <div class="llms-question-tag">
        <label for="llms_question_tag">Question Tag</label>
        <select name="llms_question_tag" id="llms_question_tag">
        <?php
        $allValues = array_unique($allValues);
        foreach ($allValues as $tag) {
            $term = get_term($tag, 'llms_question_tag');
            echo '<option value="' . $term->term_id . '">' . $term->name . '</option>';
        }
        ?>
        </select>
        </div>
        <?php
    }

    public function get_the_post_id_by_title($target_title) {
        $args = array(
            'post_type'      => 'llms_question',
            'post_status'    => 'any', // You can change this to 'publish' if you only want published posts
            'posts_per_page' => -1,
        );

        $query = new WP_Query($args);

        $post_data = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id          = get_the_ID();
                $post_title       = get_the_title();
                $post_data[$post_id] = $post_title;
            }
            wp_reset_postdata(); // Reset post data to the main query

            // Search for the target title in the array
            $matching_id = array_search($target_title, $post_data);

            if ($matching_id !== false) {
                return $matching_id;
            } else {
                return false; // Title not found
            }
        } else {
            echo "No posts found";
            return false; // No posts found
        }
    }
    
    /**
     * Register a custom menu page.
     */
    public function wpdocs_register_my_custom_menu_page() {
        add_menu_page(
            __( 'Inkubate Insight', 'textdomain' ),
            __( 'Inkubate Insight', 'textdomain' ),
            'manage_options',
            'inkubate_insight',
            array( $this, 'inkubate_insight_callback' ),
            'dashicons-chart-pie',
            50
        );
    }

    public function inkubate_insight_callback() {
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php _e( 'Inkubate Insight', 'textdomain' ); ?></h1>
    
            <label for="course-category"><?php _e( 'Choose Your Course Category:', 'textdomain' ); ?></label>
            <select id="course-category">
                <option value="business"><?php _e( 'Business & Finance', 'textdomain' ); ?></option>
                <option value="technology"><?php _e( 'Technology & Programming', 'textdomain' ); ?></option>
                <!-- Add more options as needed -->
            </select>
    
            <div id="charts-container">
                <canvas id="performance-overview" width="200" height="100"></canvas>
                <canvas id="topic-wise-proficiency" width="400" height="200"></canvas>
                <canvas id="time-management" width="400" height="200"></canvas>
                <canvas id="quiz-completion-trends" width="400" height="200"></canvas>
            </div>
        </div>
        <?php
    }

    public function update_question_tag_meta() {
        $post_id = $_POST['post_id'];
        $meta_key = $_POST['meta_key'];
        $meta_value = $_POST['meta_value'];

        update_post_meta($post_id, $meta_key, $meta_value);

        wp_die();
    }

    public function get_question_tag_meta() {
        $post_id = $_POST['post_id'];
        $meta_key = $_POST['meta_key'];

        $current_meta_value = get_post_meta($post_id, $meta_key, true);

        wp_send_json_success($current_meta_value);

        wp_die();
    }

    public function update_insight_table($student_id, $quiz_id, $attempt) {
        global $wpdb;
    
        // Define your table name
        $table_name = $wpdb->prefix . 'inkubate_insight';
        $attempt = 1;
        $user_id = $student_id;
        if ($user_id) {
            $query2 = $wpdb->prepare(
                "SELECT questions
                FROM {$wpdb->prefix}lifterlms_quiz_attempts
                WHERE student_id = %d
                AND quiz_id = %d
                AND (status = %s OR status = %s)
                ORDER BY id DESC
                LIMIT 1",
                $student_id,
                $quiz_id,
                'fail',
                'pass'
            );
            $questions = $wpdb->get_col($query2);
            $ids = $earned = array();
            foreach ($questions as $serializedData) {
                // Unserialize the data
                $unserializedData = unserialize($serializedData);
    
                // Check if $unserializedData is an array
                if (is_array($unserializedData)) {
                    foreach ($unserializedData as $data) {
                        // Check if the 'id' key is present in the nested array
                        if (isset($data['id'])) {
                            $ids[] = $data['id'];
                            $earned[] = $data['earned'];
                        }
                    }
                }
            }
            // Process each question separately
            foreach ($ids as $index => $question_id) {
                $earned_point = $earned[$index];

                // Fetch additional data based on $question_id if needed
                $question_tag_id = get_post_meta((int)$question_id, 'question_tag', true);

                $lesson_id = get_post_meta($quiz_id, '_llms_lesson_id', true);
                $parent_course = get_post_meta($lesson_id, '_llms_parent_course', true);

                $term_lists = wp_get_post_terms($parent_course, 'course_cat', array('fields' => 'ids'));
                $question_tags = array();
                foreach ($term_lists as $term_id) {
                    $question_tags[] = $term_id;
                }

                // Iterate over each question tag and accumulate scores
                foreach ($question_tags as $term_ids) {
                    // Check if a row with the given student_id, question_tag_id, and category_id exists
                    $existing_row = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT * FROM $table_name WHERE student_id = %d AND question_tag_id = %d AND category_id = %d",
                            $student_id,
                            $question_tag_id,
                            $term_ids
                        )
                    );

                    // Prepare data for updating or inserting
                    $data = array(
                        'student_id'      => $student_id,
                        'category_id'     => $term_ids,
                        'question_tag_id' => $question_tag_id,
                        'score'           => $earned_point,
                        // Add other fields as needed
                    );

                    $attempt_table_name = $wpdb->prefix . 'lifterlms_quiz_attempts';

                    // Query to retrieve the last row from the table
                    $attempt_query = $wpdb->prepare("SELECT * FROM $attempt_table_name ORDER BY id DESC LIMIT 1");

                    // Get the last row
                    $last_row = $wpdb->get_row($attempt_query);

                    // Check if the last row exists and the 'attempt' field is 1
                    if ($last_row && $last_row->attempt == 1) {

                        if ($existing_row) {
                            // Row exists, update the existing row by adding the new score to the existing score
                            $data['score'] += $existing_row->score;
                            $where = array(
                                'id' => $existing_row->id,
                            );
                            $wpdb->update($table_name, $data, $where);
                        } else {
                            // Row doesn't exist, insert a new row
                            $wpdb->insert($table_name, $data);
                        }
                    }
                }
            }
        }
    }

    public function inkubate_insight_chart_shortcode($atts) {
        ob_start(); // Start output buffering
    
        ?>
        <style>
            /* Add your custom styles here */
            .main-divs {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
            }
    
            .lined-div {
                width: 48%; /* Adjust the width as needed */
                border: 1px solid #000; /* Add your preferred border style */
                padding: 10px;
                margin-bottom: 10px; /* Add margin between the divs */
                box-sizing: border-box; /* Include padding and border in the width */
            }
        </style>
    
        <div class="main-divs">
            <?php
            $taxonomy = 'course_cat'; // Replace with your taxonomy name
            $post_type = 'course'; // Replace with your custom post type name
        
            $terms = get_terms(array(
                'taxonomy' => $taxonomy,
                'hide_empty' => true, // Set to true to hide empty categories
            ));

            // Shortcode attributes
            $atts = shortcode_atts(
                array(
                    'count' => count($terms), // default value is 5 if not specified
                ),
                $atts,
                'inkubate_insight_chart'
            );
        
            $course_categories =  $terms;

            // Limit the number of categories based on the attribute
            $course_categories = array_slice($course_categories, 0, intval($atts['count']));

            // Loop to generate divs
            foreach ($course_categories as $category) {
                global $wpdb;
                $current_user_id = get_current_user_id();
                $category_id = $category->term_id; // Replace with the actual category ID you have
    
                $table_name = $wpdb->prefix . 'inkubate_insight';
    
                // Get individual scores for the specified category and user
                $query_individual = $wpdb->prepare("SELECT question_tag_id, score FROM $table_name WHERE student_id = %d AND category_id = %d", $current_user_id, $category_id);
                $results_individual = $wpdb->get_results($query_individual, ARRAY_A);
                $scores_by_tag_individual = array();
    
                if ($results_individual) {
                    foreach ($results_individual as $result) {
                        $question_tag_id = $result['question_tag_id'];
                        $score = $result['score'];
    
                        // Build an array of scores for each tag ID
                        $scores_by_tag_individual[] = $question_tag_id . '_' . $score;
                    }

                    // Get average scores for the specified category
                    $query_average = $wpdb->prepare("SELECT question_tag_id, AVG(score) as average_score FROM $table_name WHERE category_id = %d GROUP BY question_tag_id", $category_id);
                    $results_average = $wpdb->get_results($query_average, ARRAY_A);
                    $scores_by_tag_average = array();

                    if ($results_average) {
                        foreach ($results_average as $result) {
                            $question_tag_id = $result['question_tag_id'];

                            // Check if there are multiple rows with the same tag ID
                            $query_multiple_rows = $wpdb->prepare("SELECT score FROM $table_name WHERE category_id = %d AND question_tag_id = %d", $category_id, $question_tag_id);
                            $results_multiple_rows = $wpdb->get_results($query_multiple_rows, ARRAY_A);

                            $sum_of_scores = 0;
                            $count_of_rows = 0;

                            if ($results_multiple_rows) {
                                foreach ($results_multiple_rows as $row) {
                                    $sum_of_scores += $row['score'];
                                    $count_of_rows++;
                                }
                            }

                            // Calculate the average score for the tag ID
                            $average_score = $count_of_rows > 0 ? $sum_of_scores / $count_of_rows : 0;

                            // Build an array of average scores for each tag ID
                            $scores_by_tag_average[] = $question_tag_id . '_' . $average_score;
                        }
                    }

                    ?>
                    <div class="lined-div" data-secured-score="<?php echo esc_attr(implode(",", $scores_by_tag_individual)); ?>" data-average-score="<?php echo esc_attr(implode(",", $scores_by_tag_average)); ?>">
                        <canvas id="performance-overview-<?php echo esc_html($category->slug);?>" width="400" height="200"></canvas>
                        <h2><?php echo esc_html($category->name); ?></h2>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
        <?php
    
        return ob_get_clean(); // Return the buffered content
    }
}
new LLMS_Inkubate_Insights();