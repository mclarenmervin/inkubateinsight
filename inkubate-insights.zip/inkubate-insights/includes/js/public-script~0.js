document.addEventListener('DOMContentLoaded', function () {

    // Check if body has an element with the class 'main-divs'
    var mainDivsElement = document.querySelector('.main-divs');

    // Check if the element is present and is empty
    if (mainDivsElement && mainDivsElement.children.length === 0) {
        // Add an h2 element with the specified text
        var h2Element = document.createElement('h2');
        var textNode = document.createTextNode('Complete quizzes to see insights.');
        h2Element.appendChild(textNode);
        mainDivsElement.appendChild(h2Element);
    }

    // Define your category names
    var categories = inkubateInsightP.categorySlug;
    var tagNames = inkubateInsightP.categoryNames;
    var tagIds = inkubateInsightP.categoryIds;
    
    // Create an object with tagId as key and tagName as value
    var tagIdNameMap = tagIds.reduce(function (acc, tagId, index) {
        acc[tagId] = tagNames[index];
        return acc;
    }, {});

    // Loop through categories and create charts
    categories.forEach(function (category) {
        createChart(category);
    });

    function createChart(category) {
        var canvas = document.getElementById('performance-overview-' + category);

        // Check if the canvas element exists
        if (canvas) {
            // Get the canvas context for the current category
            var ctx = canvas.getContext('2d');

            // Get the data from the data-secured-course attribute
            var securedCourseData = canvas.parentElement.getAttribute('data-secured-score');

            // Get the tagIds array
            var tagIds = inkubateInsightP.categoryIds;

            // Initialize an array to store scores in the order of tag IDs
            var securedData = Array(tagIds.length).fill(0);

            // Check if securedCourseData is not null and is a string
            if (securedCourseData !== null && typeof securedCourseData === 'string') {
                // Split the data into an array of tag ID and score pairs
                var tagScorePairs = securedCourseData.split(',');

                // Map the scores to tagIds
                tagScorePairs.forEach(function (pair) {
                    var [currentTagId, score] = pair.split('_');
                    var index = tagIds.indexOf(parseInt(currentTagId, 10));

                    if (index !== -1) {
                        securedData[index] = parseInt(score, 10);
                    }
                });
            }

            // Get the data from the data-average-score attribute
            var averageCourseData = canvas.parentElement.getAttribute('data-average-score');

            // Initialize an array to store average scores in the order of tag IDs
            var averageData = Array(tagIds.length).fill(0);

            // Check if averageCourseData is not null and is a string
            if (averageCourseData !== null && typeof averageCourseData === 'string') {
                // Split the data into an array of tag ID and average score pairs
                var tagAveragePairs = averageCourseData.split(',');

                // Map the average scores to tagIds
                tagAveragePairs.forEach(function (pair) {
                    var [currentTagId, averageScore] = pair.split('_');
                    var index = tagIds.indexOf(parseInt(currentTagId, 10));

                    if (index !== -1) {
                        averageData[index] = parseFloat(averageScore);
                    }
                });
            }

            // Find indices where securedData values are 0
            const zeroIndices = securedData.reduce((indices, value, index) => {
                if (value === 0) {
                    indices.push(index);
                }
                return indices;
            }, []);

            // Create new arrays excluding elements at zeroIndices
            const filteredTagNames = tagNames.filter((_, index) => !zeroIndices.includes(index));
            const filteredSecuredData = securedData.filter((_, index) => !zeroIndices.includes(index));
            const filteredAverageData = averageData.filter((_, index) => !zeroIndices.includes(index));

            // Create the chart
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: filteredTagNames, // Make sure inkubateInsightP is defined
                    datasets: [
                        {
                            label: 'Secured Percentage',
                            backgroundColor: 'rgba(0, 143, 193, 1)',
                            borderColor: 'rgba(0, 143, 193, 1)',
                            borderWidth: 1,
                            data: filteredSecuredData // Use the appropriate data for the category
                        },
                        {
                            label: 'Average Percentage',
                            backgroundColor: 'rgba(240, 72, 39, 1)',
                            borderColor: 'rgba(240, 72, 39, 1)',
                            borderWidth: 1,
                            data: filteredAverageData // Use the appropriate data for the category
                        }
                    ]
                },
                options: {
                    scales: {
                        x: {
                            barPercentage: 0.4,
                            categoryPercentage: 0.5,
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                                callback: function (value) {
                                    return value;
                                }
                            }
                        }
                    }
                }
            });
        }
    }
});
