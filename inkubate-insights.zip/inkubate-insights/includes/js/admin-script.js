var $ = jQuery;
if($('body').find('#llms_question_tagm').length > 0) {
    $('#llms_question_tagm').select2();
}

document.addEventListener('DOMContentLoaded', function () {
    function updateCharts(selectedCategory) {
        var performanceOverviewCtx = document.getElementById('performance-overview').getContext('2d');
        var performanceOverviewChart = new Chart(performanceOverviewCtx, {
            type: 'bar',
            data: {
                labels: inkubateInsight.categoryNames,
                datasets: [
                    {
                        label: 'Secured Percentage',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1,
                        data: [10, 20, 30, 40] // Adjust the data accordingly
                    },
                    {
                        label: 'Average Percentage',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1,
                        data: [15, 25, 35, 45] // Adjust the data accordingly
                    }
                ]
            },
            options: {
                scales: {
                    x: {
                        barPercentage: 0.4,
                        categoryPercentage: 0.5,
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 10, // Set the step size to 10
                            callback: function (value) {
                                return value; // Display the tick values directly
                            }
                        }
                    }
                }
            }
        });

        // Add similar code for other charts based on the selected category
    }

    updateCharts(document.getElementById('course-category').value);

    document.getElementById('course-category').addEventListener('change', function () {
        updateCharts(this.value);
    });
});

jQuery(document).ready(function() {

    var intervalId; // Declare intervalId in a higher scope

    // Wrap your code in a function to avoid polluting the global scope
    function checkSelectedValue() {
        var selectElements = $('#llms-quiz-questions .llms-question-body.active .llms-question-tag #llms_question_tag');

        selectElements.each(function() {
            var selectElement = $(this);

            // Check if the class 'option-changed' exists
            if (selectElement.hasClass('option-changed')) {
            } else {
                // Get the post ID
                var parentid = $(this).closest('.llms-question-body.active').parent().attr('id');
                var numbersArray = parentid.split('-');
                var lastNumber = numbersArray[numbersArray.length - 1];

                // Update post meta
                var postId = lastNumber;
                var metaKey = 'question_tag';

                jQuery.ajax({
                    type: 'POST',
                    url: inkubateInsight.ajaxurl, // ajaxurl is defined by WordPress and contains the URL to admin-ajax.php
                    data: {
                        action: 'get_question_tag_meta',
                        post_id: postId,
                        meta_key: metaKey,
                    },
                    success: function(response) {
                        // Set the selected option based on the response
                        selectElement.val(response.data);
                        selectElement.addClass('option-changed');
                        // console.log(response.data);
                    },
                    error: function(error) {
                        // Handle the error if needed
                        console.error(error);
                    }
                });
            }
        });
    }

    // Set up the interval to periodically check for changes
    intervalId = setInterval(checkSelectedValue, 1000);

    checkSelectedValue();

    $('body').on( 'change', '#llms-quiz-questions .llms-question-body.active .llms-question-tag #llms_question_tag', function() {
        // Get the selected value
        var selectedValue = $(this).val();

        // Get the post ID
        var parentid = $(this).closest('.llms-question-body.active').parent().attr('id');
        var numbersArray = parentid.split('-');
        var lastNumber = numbersArray[numbersArray.length - 1];

        // Update post meta
        var postId = lastNumber;
        var metaKey = 'question_tag';

        // Check if a value is selected before updating the post meta
        if (selectedValue) {
            // Use AJAX to update post meta
            jQuery.ajax({
                type: 'POST',
                url: inkubateInsight.ajaxurl, // ajaxurl is defined by WordPress and contains the URL to admin-ajax.php
                data: {
                    action: 'update_question_tag_meta',
                    post_id: postId,
                    meta_key: metaKey,
                    meta_value: selectedValue,
                },
                success: function(response) {
                    // Handle the success response if needed
                    console.log(response);
                },
                error: function(error) {
                    // Handle the error if needed
                    console.error(error);
                }
            });
        }
    });
});