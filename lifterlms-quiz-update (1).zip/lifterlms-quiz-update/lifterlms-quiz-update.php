<?php
/**
 * Plugin Name: LifterLMS - Clickable, Paginated Progress Bar for Quiz Questions
 * Plugin URI: 
 * Description: LifterLMS - Clickable, Paginated Progress Bar for Quiz Questions
 * Version: 1.0
 * Author: Magnigenie
 * Author URI: https://magnigenie.com
 */

defined( 'ABSPATH' ) || exit;

if ( !defined( 'LLMS_QUIZ_UPDATE_FILE' ) ) {
    define( 'LLMS_QUIZ_UPDATE_FILE', __FILE__ );
}

if ( !defined( 'LLMS_QUIZ_UPDATE_DIR' ) ) {
    define( 'LLMS_QUIZ_UPDATE_DIR', dirname( __FILE__ ) );
}

if ( !class_exists( 'LLMS_QUIZ_UPDATE' ) ) {
    include_once dirname( __FILE__ ) . '/includes/class-quiz-update.php';
}