<?php
class LLMS_QUIZ_UPDATE {

    public function __construct() {
        
        // Hook into the lifterlms_display_course_progress_bar filter.
        // add_filter( 'lifterlms_display_course_progress_bar', array( $this, 'custom_lifterlms_progress_bar_text' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'lifterlms_quiz_progress_bar_js' ) );

        // Add AJAX action for retrieving data
        add_action( 'wp_ajax_get_bubble_count', array( $this, 'get_bubble_count_callback' ) );
        add_action( 'jump_to_next_question', array( $this, 'jump_to_next_question_callback' ) );

        // add_action( 'wp_enqueue_scripts', array( $this, 'dequeue_llms_quiz_script' ), 100 );
    }

    // Add this code to your theme's functions.php file or your custom plugin file
    function dequeue_llms_quiz_script() {
        if ( is_singular( 'llms_quiz' ) ) {
            // Replace 'llms-quiz' with the actual handle of the script you want to dequeue
            wp_dequeue_script( 'llms-quiz' );
        }
    }

    public function lifterlms_quiz_progress_bar_js() {

		// Enqueue Bootstrap CSS
		wp_enqueue_style('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');

		// Enqueue jQuery
		wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js', array(), null, true);
	
		// Enqueue Bootstrap JS
		wp_enqueue_script('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js', array('jquery'), null, true);

        wp_enqueue_script( 'lifterlms-progress-bar-script', plugins_url('js/script.js', __FILE__), array('jquery'), '1.0', true );
        
        wp_enqueue_style( 'lifterlms-progress-bar-styles', plugins_url('css/styles.css', __FILE__), array(), '1.0', 'all');

        // Localize the script with the admin URL
        wp_localize_script( 'lifterlms-progress-bar-script', 'adminAjax', array(
            'url'       => admin_url('admin-ajax.php'),
        ));
    }

    // Add this code to your theme's functions.php file or a custom plugin.
    public function custom_lifterlms_progress_bar_text() {
        // Modify or add your custom text here.
        $custom_text = 'Your custom text goes here';

        // Append your custom text to the existing output.
        $output .= '<div class="custom-progress-text">' . esc_html($custom_text) . '</div>';

        // Return the modified output.
        return $output;
    }

    public static function jump_to_next_question_callback( $request ) {

		$err = new WP_Error();

		$student = llms_get_student();
		if ( ! $student ) {
			$err->add( 400, __( 'You must be logged in to take quizzes.', 'lifterlms' ) );
			return $err;
		}

		$required = array( 'attempt_key', 'question_id', 'question_type' );
		foreach ( $required as $key ) {
			if ( ! isset( $request[ $key ] ) ) {
				$err->add( 400, __( 'Missing required parameters. Could not proceed.', 'lifterlms' ) );
				return $err;
			}
		}

		$attempt_key = sanitize_text_field( $request['attempt_key'] );
		$question_id = absint( $request['question_id'] );
		$answer      = array_map( 'stripslashes_deep', isset( $request['answer'] ) ? $request['answer'] : array() );

		$student_quizzes = $student->quizzes();
		$attempt         = $student_quizzes->get_attempt_by_key( $attempt_key );
		if ( ! $attempt ) {
			$err->add( 500, __( 'There was an error recording your answer. Please return to the lesson and begin again.', 'lifterlms' ) );
			return $err;
		}

		/**
		 * Check limit not reached.
		 *
		 * First check whether the quiz is open (so to leverage the `llms_quiz_is_open` filter ),
		 * if not, check also for remaining attempts.
		 *
		 * At this point the current attempt has already been counted (maybe the last allowed),
		 * so we check that the remaining attempt is just greater than -1.
		 */
		$quiz_id = $attempt->get( 'quiz_id' );
		if ( ! ( new LLMS_Quiz( $quiz_id ) )->is_open() &&
				$student_quizzes->get_attempts_remaining_for_quiz( $quiz_id, true ) < 0 ) {
			$err->add( 400, __( "You've reached the maximum number of attempts for this quiz.", 'lifterlms' ) );
			return $err;
		}

		// record the answer.
		$attempt->answer_question( $question_id, $answer );

		// get the next question.
		$question_id = $attempt->get_next_question( $question_id );

		// return html for the next question.
		if ( $question_id ) {

			$html = llms_get_template_ajax(
				'content-single-question.php',
				array(
					'attempt'  => $attempt,
					'question' => llms_get_post( $question_id ),
				)
			);

			return array(
				'html'        => $html,
				'question_id' => $question_id,
			);

		} else {

			return self::quiz_end( $request, $attempt );

		}

	}

    public function get_bubble_count_callback() {

        // Get the value of p from the AJAX request
        $pValue = sanitize_text_field($_POST['pValue']);
    
        // Run the database query
        global $wpdb;
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = '_llms_parent_id' AND meta_value = %d",
            $pValue
        ));
    
        // Return the result as JSON
        wp_send_json($result);
    }

}
new LLMS_QUIZ_UPDATE();