jQuery(document).ready(function ($) {

    function waitForElement() {
        // Check if the element exists
        if ( $('#llms-quiz-ui #llms-quiz-header').length && $('#llms-quiz-ui #llms-quiz-nav').length ) {

            // If it exists, add text
            $('#llms-quiz-ui #llms-quiz-header .llms-progress').remove();

            // Use setInterval to check for the element periodically
            var checkInterval = setInterval(function() {
                // Check if the element with ID "llms-quiz-counter" exists in the body
                if ($('#llms-quiz-counter .llms-total').text().length > 0) {
                    // Element found, stop checking by clearing the interval
                    clearInterval(checkInterval);
                    // console.log('Element found!');

                    var total_question = $('body').find('#llms-quiz-counter .llms-total').text();
                    var bubbleCount = parseInt(total_question);
                    // console.log(bubbleCount);
                    // console.log(pValue);
            
                    // Generate HTML with inline CSS styles
                    var bubbleHtml = '<div class="bubble-container" id="bubble-container">';
					bubbleHtml += '<div class="bubble current" id="1">1</div>';
                    for (var i = 2; i <= bubbleCount; i++) {
                        // Customize inline styles as needed
                        bubbleHtml += '<div class="bubble" id=' + i + '>' + i + '</div>';
                    }
            
                    bubbleHtml += '</div>';
            
                    // Prepend the bubble HTML to the quiz header
                    $('#llms-quiz-ui #llms-quiz-header').prepend(bubbleHtml);

                    $('body').on('click', '#llms-quiz-header #bubble-container div.bubble, #myModal .modal-body #bubble-container div.bubble', function(e) {
						// $(this).addClass('current');
						var current_question = $('body').find('#llms-quiz-counter .llms-current').text();
                        // e.preventDefault();
                        var self = quiz;
						self.jump_to_specific_question( $(this), current_question );
                    } );

					// console.log(window.llms.quizzes);

                } else {
                    // Element not found, continue checking
                    console.log('Element not found yet.');
                }
            }, 1000); // Check every 1000 milliseconds (1 second)

        } else {
            // If it doesn't exist, wait for a short period and then check again
            setTimeout(waitForElement, 100);
        }
    }
    
    // Call the function to start the checking process
    waitForElement();

    var quiz = {
		$buttons: null,
		$container: null,
		$ui: null,
		attempt_key: null,
		current_question: 0,
		total_questions: 0,
		questions: {},
		validators: {},
		status: null,
		bind: function() {

			var self = this;

			// start quiz
			$( '#llms_start_quiz' ).on( 'click', function( e ) {
				e.preventDefault();
				self.start_quiz();
			} );

			// draw quiz grade circular chart
			$( '.llms-donut' ).each( function() {
				LLMS.Donut( $( this ) );
			} );

			// redirect to attempt on attempt selection change
			$( '#llms-quiz-attempt-select' ).on( 'change', function() {
				var val = $( this ).val();
				if ( val ) {
					window.location.href = val;
				}
			} );

			// warn when quiz is running and user tries to leave the page
			$( window ).on( 'beforeunload', function() {
				if ( self.status ) {
					return LLMS.l10n.translate( 'Are you sure you wish to quit this quiz attempt?' );
				}
			} );

			// complete the quiz attempt when user leaves if the quiz is running
			$( window ).on( 'unload', function() {
				if ( self.status ) {
					self.complete_quiz();
				}
			} );

			$( document ).on( 'llms-post-append-question', self.post_append_question );

			// register validators
			this.register_validator( 'content', this.validate );
			this.register_validator( 'choice', this.validate_choice );
			this.register_validator( 'picture_choice', this.validate_choice );
			this.register_validator( 'true_false', this.validate_choice );

		},
		add_error: function( msg ) {

			var self = this;

			self.$container.find( '.llms-error' ).remove();
			var $err = $( '<p class="llms-error">' + msg + '<a href="#"><i class="fa fa-times-circle" aria-hidden="true"></i></a></p>' );
			$err.on( 'click', 'a', function( e ) {
				e.preventDefault();
				$err.fadeOut( '200' );
				setTimeout( function() {
					$err.remove();
				}, 210 );
			} );
			self.$container.append( $err );

		},
		jump_to_specific_question: function(jumpobj,current_question) {

			var self = this;
			
			var current = parseInt(current_question);
			var clicked = parseInt(jumpobj.text());
			
			if(clicked<current) {
				var jump_length = parseInt(jumpobj.text());
				var current_q = parseInt(current);
				// // console.log(jump_length);
				// // console.log(current_q);
				var final_jump = current_q - jump_length;
				var jumpstatus = "decrement";
				// self.toggle_loader( 'show', LLMS.l10n.translate( 'Loading Question...' ) );
				// self.update_progress_bar( 'decrement' );

				// var ids     = Object.keys( self.questions ),
				// 	curr    = ids.indexOf( 'q-' + self.current_question ),
				// 	prev_id = ids[0];

				// if ( curr >= 1 ) {
				// 	prev_id = ids[ curr - final_jump ];
				// }

				// setTimeout( function() {
				// 	self.toggle_loader( 'hide' );
				// 	self.load_question( self.questions[ prev_id ] );
				// }, 100 );
			} else {

				var jump_length = parseInt(jumpobj.text());
				var current_q = parseInt(current);
				var final_jump = jump_length-current_q;
				var jumpstatus = "increment";
				
			}

			var $btn = jumpobj;
			var self      = this,
				$question = this.$container.find( '.llms-question-wrapper' ),
				type      = $question.attr( 'data-type' ),
				valid;

			// if ( ! this.validators[ type ] ) {

			// 	console.log( 'No validator registered for question type ' + type );
			// 	return;

			// }

			valid = this.validators[ type ]( $question );
			// if ( ! valid || true !== valid.valid || ! valid.answer ) {
			// 	return self.add_error( valid.valid );
			// }

			LLMS.Ajax.call( {
				data: {
					action: 'quiz_answer_specific_question',
					answer: valid.answer,
					attempt_key: self.attempt_key,
					question_id: $question.attr('data-id'),
					question_type: $question.attr( 'data-type' ),
					jump: final_jump,
					jumpstatus: jumpstatus,
				},
				beforeSend: function() {
					
					var $bubble = $('body #llms-quiz-header #bubble-container div#' + current_question);
					
					$('body #llms-quiz-counter .llms-current').text(jump_length);
					// Remove existing classes

					for (var i = current_q; i <= jump_length; i++) {
						var bubbleId = i.toString();
						var bubbleElement = document.getElementById(bubbleId);

						if (bubbleElement && !bubbleElement.classList.contains("answered")) {
							bubbleElement.classList.add("unanswered");
						}
					}

					$bubble.removeClass("answered unanswered");
					if (!$bubble.hasClass("current")) {
						if (Array.isArray(valid.answer) && valid.answer.length > 0) {
							// valid.answer is a non-empty array
							$bubble.addClass("answered");
						} else {
							// valid.answer is either not an array or an empty array
							$bubble.addClass("unanswered");
						}
					}

					// Get the initial value of llms-current
					var initialCurrentValue = $('body #llms-quiz-counter .llms-current').text();
					if( $('body #llms-quiz-counter .llms-current').text() == $('body #llms-quiz-counter .llms-total').text()) {
						$( 'body #llms-next-question' ).hide();
						$( 'body #llms-complete-quiz' ).show();
					} else {
						$( 'body #llms-next-question' ).show();
						$( 'body #llms-complete-quiz' ).hide();						
					}
					
					// Monitor changes to llms-current
					$('body #llms-quiz-counter .llms-current').on('DOMSubtreeModified', function() {
						// Get the current value of llms-current
						var currentVal = $(this).text();

						// Check if the value has changed
						if (currentVal !== initialCurrentValue) {
							$('body #llms-quiz-header #bubble-container div.bubble').removeClass('current');
							// Add the highlight class
							$("body #llms-quiz-header #bubble-container div#"+currentVal).removeClass('current answered unanswered');
							$("body #llms-quiz-header #bubble-container div#"+currentVal).addClass('current');

							// Update the initial value for the next check
							initialCurrentValue = currentVal;
						}
					});

					var msg = $btn.hasClass( 'llms-button-quiz-complete' ) ? LLMS.l10n.translate( 'Grading Quiz...' ) : LLMS.l10n.translate( 'Loading Question...' );
					self.toggle_loader( 'show', msg );

					self.update_progress_bar( 'increment' );
				},
				success: function( r ) {
					self.toggle_loader( 'hide' );

					if ( r.data && r.data.html ) {

						// load html from the cached questions if it exists already
						if ( r.data.question_id && self.questions[ 'q-' + r.data.question_id ] ) {

							self.load_specific_question( self.questions[ 'q-' + r.data.question_id ] );

							// load html from server if the question's never been seen before
						} else {
							self.load_specific_question( r.data.html );
						}

					} else if ( r.data && r.data.redirect ) {

						self.redirect( r.data.redirect );

					} else if ( r.message ) {

						self.$container.append( '<p>' + r.message + '</p>' );

					} else {

						var msg = LLMS.l10n.translate( 'An unknown error occurred. Please try again.' );
						self.$container.append( '<p>' + msg + '</p>' );

					}

				}

			} );
		},
		answer_question: function( $btn, current_question ) {

			var self      = this,
				$question = this.$container.find( '.llms-question-wrapper' ),
				type      = $question.attr( 'data-type' ),
				valid;

			if ( ! this.validators[ type ] ) {

				console.log( 'No validator registered for question type ' + type );
				return;

			}

			valid = this.validators[ type ]( $question );
			if ( ! valid || true !== valid.valid || ! valid.answer ) {
				return self.add_error( valid.valid );
			}

			LLMS.Ajax.call( {
				data: {
					action: 'quiz_answer_question',
					answer: valid.answer,
					attempt_key: self.attempt_key,
					question_id: $question.attr( 'data-id' ),
					question_type: $question.attr( 'data-type' ),
				},
				beforeSend: function() {

					var $bubble = $('body #llms-quiz-header #bubble-container div#' + current_question);
					// Get the initial value of llms-current
					var initialCurrentValue = $('body #llms-quiz-counter .llms-current').text();

					// Monitor changes to llms-current
					$('body #llms-quiz-counter .llms-current').on('DOMSubtreeModified', function() {
						// Get the current value of llms-current
						var currentVal = $(this).text();

						// Check if the value has changed
						if (currentVal !== initialCurrentValue) {
							$('body #llms-quiz-header #bubble-container div.bubble').removeClass('current');
							// Add the highlight class
							$('body #llms-quiz-header #bubble-container div#' + currentVal).addClass('current');

							// Update the initial value for the next check
							initialCurrentValue = currentVal;
						}
					});
					// Remove existing classes
					$bubble.removeClass("answered unanswered");

					if (Array.isArray(valid.answer) && valid.answer.length > 0) {
						// valid.answer is a non-empty array
						$bubble.addClass("answered");
					} else {
						// valid.answer is either not an array or an empty array
						$bubble.addClass("unanswered");
					}

					var msg = $btn.hasClass( 'llms-button-quiz-complete' ) ? LLMS.l10n.translate( 'Grading Quiz...' ) : LLMS.l10n.translate( 'Loading Question...' );
					self.toggle_loader( 'show', msg );

					self.update_progress_bar( 'increment' );

				},
				success: function( r ) {

					self.toggle_loader( 'hide' );

					if ( r.data && r.data.html ) {

						// load html from the cached questions if it exists already
						if ( r.data.question_id && self.questions[ 'q-' + r.data.question_id ] ) {

							self.load_question( self.questions[ 'q-' + r.data.question_id ] );

							// load html from server if the question's never been seen before
						} else {
							self.load_question( r.data.html );
						}

					} else if ( r.data && r.data.redirect ) {

						self.redirect( r.data.redirect );

					} else if ( r.message ) {

						self.$container.append( '<p>' + r.message + '</p>' );

					} else {

						var msg = LLMS.l10n.translate( 'An unknown error occurred. Please try again.' );
						self.$container.append( '<p>' + msg + '</p>' );

					}

				}

			} );

		},
		complete_quiz: function() {

			var self = this;

			LLMS.Ajax.call( {
				data: {
					action: 'quiz_end',
					attempt_key: self.attempt_key,
				},
				beforeSend: function() {

					self.toggle_loader( 'show', 'Grading Quiz...' );

				},
				success: function( r ) {

					self.toggle_loader( 'hide' );

					if ( r.data && r.data.redirect ) {

						self.redirect( r.data.redirect );

					} else if ( r.message ) {

						self.$container.append( '<p>' + r.message + '</p>' );

					} else {

						var msg = LLMS.l10n.translate( 'An unknown error occurred. Please try again.' );
						self.$container.append( '<p>' + msg + '</p>' );

					}

				}

			} );

		},
		get_question_index: function( qid ) {

			return Object.keys( this.questions ).indexOf( 'q-' + qid );

		},
		redirect: function( url ) {

			this.toggle_loader( 'show', 'Grading Quiz...' );
			this.status          = null;
			window.location.href = url;

		},
		previous_question: function() {

			var self = this;

			self.toggle_loader( 'show', LLMS.l10n.translate( 'Loading Question...' ) );
			self.update_progress_bar( 'decrement' );

			var ids     = Object.keys( self.questions ),
				curr    = ids.indexOf( 'q-' + self.current_question ),
				prev_id = ids[0];

			if ( curr >= 1 ) {
				prev_id = ids[ curr - 1 ];
			}

			setTimeout( function() {
				self.toggle_loader( 'hide' );
				self.load_question( self.questions[ prev_id ] );
			}, 100 );

		},
		register_validator: function( type, func ) {

			this.validators[ type ] = func;

		},
		start_quiz: function () {

			var self = this;

			this.load_ui_elements();
			this.$ui        = $( '#llms-quiz-ui' );
			this.$buttons   = $( '#llms-quiz-nav button' );
			this.$container = $( '#llms-quiz-question-wrapper' );

			// bind submission event for answering questions
			$( '#llms-next-question' ).on( 'click', function( e ) {
				var current_question = $('body').find('#llms-quiz-counter .llms-current').text();
				e.preventDefault();
				self.answer_question( $( this ), current_question );
			} );

			$( '#llms-complete-quiz-final' ).on( 'click', function( e ) {
				var current_question = $('body').find('#llms-quiz-counter .llms-current').text();
				e.preventDefault();
				self.complete_quiz();
			} );

			// $('body #llms-next-question').click(function() {
			// 	var current_bubble = $('body #bubble-container div.current');
			// 	var nextBubble = current_bubble.next(".bubble");

			// 	// Check if there is a next div
			// 	if (nextBubble.length) {
			// 		// Add the "current" class to the next div
			// 		nextBubble.click();
			// 	}
			// });

			$('body #llms-complete-quiz').click(function() {
				// Get all answered and unanswered divs
				$('body #llms-quiz-header #bubble-container div.current').removeClass('unanswered').addClass('answered');
				var answeredDivs = $('body #llms-quiz-header #bubble-container div.answered');
				var unansweredDivs = $('body #llms-quiz-header #bubble-container div.unanswered');
		  
				// Create an HTML string to display the questions
				var html = '<h2>Answered Questions:</h2>';
				html += '<div id="bubble-container">';
				answeredDivs.each(function() {
				  var questionNumber = $(this).text();
				  html += '<div class="bubble answered" data-dismiss="modal">' + questionNumber + '</div>';
				});
				html += '</div>';
				html += '<h2>Unanswered Questions:</h2>';
				html += '<div id="bubble-container">';
				unansweredDivs.each(function() {
				  var questionNumber = $(this).text();
				  html += '<div class="bubble unanswered" data-dismiss="modal">' + questionNumber + '</div>';
				});
				html += '</div>';
				// Display the HTML
				$('body #myModal .modal-body').html(html);
			});

			// bind submission event for navigating backwards
			$( '#llms-prev-question' ).on( 'click', function( e ) {
				e.preventDefault();
				self.previous_question();
			} );

			LLMS.Ajax.call( {
				data: {
					action: 'quiz_start',
					attempt_key: $( '#llms-attempt-key' ).val(),
					lesson_id : $( '#llms-lesson-id' ).val(),
					quiz_id : $( '#llms-quiz-id' ).val(),
				},
				beforeSend: function() {

					self.status = true;
					$( '#llms-quiz-wrapper, #quiz-start-button' ).remove();
					$( 'html, body' ).stop().animate( {scrollTop: 0 }, 500 );
					self.toggle_loader( 'show', LLMS.l10n.translate( 'Loading Quiz...' ) );

				},
				error: function( r, s, t ) {
					console.log( r, s, t );
				},
				success: function( r ) {

					self.toggle_loader( 'hide' );

					if ( r.data && r.data.html ) {

						// start the quiz timer when a time limit is set
						if ( r.data.time_limit ) {
							self.start_quiz_timer( r.data.time_limit );
						}

						self.attempt_key     = r.data.attempt_key;
						self.total_questions = r.data.total;

						self.load_question( r.data.html );

					} else if ( r.message ) {

						self.$container.append( '<p>' + r.message + '</p>' );

					} else {

						var msg = LLMS.l10n.translate( 'An unknown error occurred. Please try again.' );
						self.$container.append( '<p>' + msg + '</p>' );

					}

				}

			} );

			/**
			 * Use JS mouse events instead of CSS :hover because iOS is really smart
			 *
			 * @see: https://css-tricks.com/annoying-mobile-double-tap-link-issue/
			 */
			if ( ! LLMS.is_touch_device() ) {

				this.$ui.on( 'mouseenter', 'li.llms-choice label', function() {
					$( this ).addClass( 'hovered' );
				} );
				this.$ui.on( 'mouseleave', 'li.llms-choice label', function() {
					$( this ).removeClass( 'hovered' );
				} );

			}

		},
		start_quiz_timer: function( total_minutes ) {

			// create and append the UI for the countdown clock
			var $el = $( '<div class="llms-quiz-timer" id="llms-quiz-timer" />' ),
				msg = LLMS.l10n.translate( 'Time Remaining' );

			$el.append( '<i class="fa fa-clock-o" aria-hidden="true"></i><span class="screen-reader-text">' + msg + '</span>' );
			$el.append( '<div id="llms-tiles" class="llms-tiles"></div>' );

			$( '#llms-quiz-header' ).append( $el );

			// start the timer
			var self        = this,
				target_date = new Date().getTime() + ( ( total_minutes * 60 ) * 1000 ), // set the countdown date
				time_limit  = ( ( total_minutes * 60 ) * 1000 ),
				countdown   = document.getElementById( 'llms-tiles' ), // get tag element
				days, hours, minutes, seconds; // variables for time units

			// set actual timer
			setTimeout( function() {
				self.complete_quiz();
			}, time_limit + 1000 );

			this.getCountdown(
				total_minutes,
				target_date,
				time_limit,
				days,
				hours,
				minutes,
				seconds,
				countdown
			);

			// call get_count_down every 1 second
			setInterval( function () {
				self.getCountdown(
					total_minutes,
					target_date,
					time_limit,
					days,
					hours,
					minutes,
					seconds,
					countdown
				);
			}, 1000 );
		},
		trigger: function( event ) {

			var self = this;

			// trigger question submission for the current question
			if ( 'answer_question' === event ) {

				if ( this.get_question_index( self.current_question ) === self.total_questions ) {

					$( '#llms-complete-quiz' ).trigger( 'click' );

				} else {

					$( '#llms-next-question' ).trigger( 'click' );

				}

			}

		},
		load_question: function( html ) {

			var $html = $( html ),
				qid   = $html.attr( 'data-id' );

			// cache the question HTML for faster rewinds
			if ( ! this.questions[ 'q-' + qid ] ) {
				this.questions[ 'q-' + qid ] = $html;
			}

			this.update_progress( qid );

			this.current_question = qid;

			$( document ).trigger( 'llms-pre-append-question', $html );

			this.$container.append( $html );

			$( document ).trigger( 'llms-post-append-question', $html );

		},
		load_specific_question: function( html ) {

			var $html = $( html ),
				qid   = $html.attr( 'data-id' );

			// cache the question HTML for faster rewinds
			if ( ! this.questions[ 'q-' + qid ] ) {
				this.questions[ 'q-' + qid ] = $html;
			}

			// this.update_specific_progress( qid );

			this.current_question = qid;

			$( document ).trigger( 'llms-pre-append-question', $html );

			this.$container.append( $html );

			$( document ).trigger( 'llms-post-append-question', $html );

		},
		load_ui_elements: function() {

			var $html   = $( '<div class="llms-quiz-ui" id="llms-quiz-ui" />' ),
				$header = $( '<header class="llms-quiz-header" id="llms-quiz-header" />' )
				$footer = $( '<footer class="llms-quiz-nav" id="llms-quiz-nav" />' );

			$footer.append( '<button class="button large llms-button-action" id="llms-next-question" name="llms_next_question" type="submit">' + LLMS.l10n.translate( 'Next Question' ) + '</button>' );
			$footer.append( '<button class="button large llms-button-action llms-button-quiz-complete" data-toggle="modal" data-target="#myModal" id="llms-complete-quiz" name="llms_complete_quiz" type="submit" style="display:none;">' + LLMS.l10n.translate( 'Complete Quiz' ) + '</button>' );
			$footer.append( '<button class="button large llms-button-secondary" id="llms-prev-question" name="llms_prev_question" type="submit" style="display:none;">' + LLMS.l10n.translate( 'Previous Question' ) + '</button>' );

			$header.append( '<div class="llms-progress"><div class="progress-bar-complete"></div></div>' );
			$footer.append( '<div class="llms-quiz-counter" id="llms-quiz-counter"><span class="llms-current"></span><span class="llms-sep">/</span><span class="llms-total"></span></div>' )

			// Add Modal HTML
			$html.append(`
				<!-- Modal -->
				<div class="modal fade" id="myModal" role="dialog">
					<div class="modal-dialog">
						<!-- Modal content-->
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Quiz Preview</h4>
							</div>
							<div class="modal-body">
								<p>Some text in the modal.</p>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-info btn-lg llms-button-quiz-complete" id="llms-complete-quiz-final" data-dismiss="modal">Submit</button>
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
				</div>
			`);
			
			$html.append( $header )
				 .append( '<div class="llms-quiz-question-wrapper" id="llms-quiz-question-wrapper" />' )
				 .append( $footer );

			$( '#llms-quiz-wrapper' ).after( $html );

		},
		post_append_question: function( event, html ) {

			var $html = $( html );

			if ( $html.find( 'audio' ).length ) {
				wp.mediaelement.initialize();
			}

		},
		toggle_loader: function( display, msg ) {

			if ( 'show' === display ) {

				msg = msg || LLMS.l10n.translate( 'Loading...' );

				this.$buttons.attr( 'disabled', 'disabled' );

				this.$container.empty();
				LLMS.Spinner.start( this.$container );
				this.$container.append( '<div class="llms-quiz-loading">' + LLMS.l10n.translate( msg ) + '</div>' );

			} else {

				LLMS.Spinner.stop( this.$container );
				this.$buttons.removeAttr( 'disabled' );
				this.$container.find( '.llms-quiz-loading' ).remove();

			}

		},
		update_progress: function( qid ) {

			var index = this.get_question_index( qid ),
				progress;

			if ( -1 === index ) {
				return;
			}

			index++;

			$( '#llms-quiz-counter .llms-current' ).text( index );
			if ( index === 1 ) {
				$( '#llms-quiz-counter .llms-total' ).text( this.total_questions );
				$( '#llms-quiz-counter' ).show();
			}

			// handle prev question
			if ( index >= 2 ) {
				$( '#llms-prev-question' ).show();
			} else {
				$( '#llms-prev-question' ).hide();
			}

			if ( index === this.total_questions ) {
				$( '#llms-next-question' ).hide();
				$( '#llms-complete-quiz' ).show();
			} else {
				$( '#llms-next-question' ).show();
				$( '#llms-complete-quiz' ).hide();
			}

		},
		update_specific_progress: function( qid ) {

			var index = this.get_question_index( qid ),
				progress;

			if ( -1 === index ) {
				return;
			}

			index++;

			// $( '#llms-quiz-counter .llms-current' ).text( index );
			if ( index === 1 ) {
				$( '#llms-quiz-counter .llms-total' ).text( this.total_questions );
				$( '#llms-quiz-counter' ).show();
			}

			// handle prev question
			if ( index >= 2 ) {
				$( '#llms-prev-question' ).show();
			} else {
				$( '#llms-prev-question' ).hide();
			}

			if ( index === this.total_questions ) {
				$( '#llms-next-question' ).hide();
				$( '#llms-complete-quiz' ).show();
			} else {
				$( '#llms-next-question' ).show();
				$( '#llms-complete-quiz' ).hide();
			}

		},
		update_progress_bar: function( dir ) {

			var index = this.get_question_index( this.current_question );
			if ( 'increment' === dir ) {
				index++;
			} else {
				index--;
			}

			progress = ( index / this.total_questions ) * 100;
			this.$ui.find( '.progress-bar-complete' ).css( 'width', progress + '%' );

		},
		getCountdown: function( total_minutes, target_date, time_limit, days, hours, minutes, seconds, countdown ){

			// find the amount of "seconds" between now and target
			var current_date = new Date().getTime(),
				seconds_left = ( target_date - current_date ) / 1000;

			if ( seconds_left >= 0 ) {

				if ( ( seconds_left * 1000 ) < ( time_limit / 2 ) ) {

					$( '#llms-quiz-timer' ).addClass( 'color-half' );

				}

				if ( ( seconds_left * 1000 ) < ( time_limit / 4 ) ) {

					$( '#llms-quiz-timer' ).removeClass( 'color-half' );
					$( '#llms-quiz-timer' ).addClass( 'color-empty' );

				}

				days         = this.pad( parseInt( seconds_left / 86400 ) );
				seconds_left = seconds_left % 86400;
				hours        = this.pad( parseInt( seconds_left / 3600 ) );
				seconds_left = seconds_left % 3600;
				minutes      = this.pad( parseInt( seconds_left / 60 ) );
				seconds      = this.pad( parseInt( seconds_left % 60 ) );

				// format countdown string + set tag value
				countdown.innerHTML = '<span class="hours">' + hours + '</span>:<span class="minutes">' + minutes + '</span>:<span class="seconds">' + seconds + '</span>';
			}
		},
		pad: function(n) {
			return (n < 10 ? '0' : '') + n;
		},
		validate: function( $question ) {
			return {
				answer: [],
				valid: true,
			};
		},
		validate_choice: function( $question ) {

			var ret     = window.llms.quizzes.validate( $question ),
				checked = $question.find( 'input:checked' );

			if ( ! checked.length ) {
				ret.valid = LLMS.l10n.translate( 'You must select an answer to continue.' );
			} else {
				checked.each( function() {
					ret.answer.push( $( this ).val() );
				} );
			}

			return ret;

		},
	};

	quiz.bind();

	window.llms = window.llms || {};
	window.llms.quizzes = quiz;

});