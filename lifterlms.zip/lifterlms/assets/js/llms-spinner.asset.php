<?php return array('dependencies' => array('wp-i18n', 'wp-polyfill'), 'version' => '668e00f3ded5c59198d2');
