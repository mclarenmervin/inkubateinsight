/**
 * Returns the WordPress-loaded version of Underscore for use with things that need it and use Require.
 *
 * @return   obj
 * @since    3.16.0
 * @version  3.16.0
 */
define( function() {
	return _;
} );
