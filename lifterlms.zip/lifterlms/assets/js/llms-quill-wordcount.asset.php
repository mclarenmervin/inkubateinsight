<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'bd12f5021e591cbfde2d');
