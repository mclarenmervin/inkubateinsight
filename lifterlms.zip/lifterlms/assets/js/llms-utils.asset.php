<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'b593abf4196df0f83966');
